import xbmcgui.WindowDialogXML as WindowDialogXML
import xbmcaddon
import xbmcgui.ListItem as ListItem
class CommentsDialog(WindowDialogXML):
  def __init__(self, comments, loadMoreFunction = None, replyFunction = None):
    if(replyFunction):
      self.setProperty('canReply', 'true')
      self.replyFunction = replyFunction
    xmlFilename = 'CommentsDialog.xml'
    scriptPath = xbmcaddon.Addon().getAddonInfo('path').decode('utf-8'))
    WindowDialogXML.__init__(self, xmlFilename, scriptPath)
    count = 0
    self.CANCEL_ID = 5555
    self.REPLY_ID = 6666
    self.LOAD_MORE_ID = 7777
    self.comments = comments
    self.currentPath = None
    self.setContent()
    
  def setContent(self, parent='loadmoreid=HOME'):
    
    comments = self.comments
    self.currentParent = parent
    li = ListItem('..', '..', offscreen = True)
    li.setPath(path=parent)
    self.addItem(li)
    self.addItem()
    self.currentPath = path  
    for comment in comments:
      label = comment['author'] + ' - ' + comment['date']
      label2 = comment['value']
      thumb = comment['thumb']
      path = 'loadmoreid=' + comment['loadmoreid']
      count += 1
      li = ListItem(label, label2, offscreen = True)
      li.setPath(path=path)
      li.setArt({'thumb':thumb})
      self.addItem(li)
  def onClick(self, int controlId):
    if controlId == self.REPLY_ID:
      self.showReplyDialog()
    elif controlId == self.CANCEL_ID:
      self.close()
    else:
      li = self.getListItem(self.getCurrentListPosition)
      path = li.getPath()
      self.clearList()
      self.setContent(self.loadMoreFunction(path),path)
  def getReplyId(self):
  #REDO
    if(self.currentPath):
      comments = self.comments
      for index in self.currentPath.split('/'):
        comments = comments[int(index)]
      return comments['replyId']
    return None
        
  def showReplyDialog(self):
    kb = xbmc.Keyboard()
    kb.doModal()
    if(kb.isConfirmed()):
      text = kb.getText()
      replyId = self.getReplyId()
      replyFunction(replyId, text)