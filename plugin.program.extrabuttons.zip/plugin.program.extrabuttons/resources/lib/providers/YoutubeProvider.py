#from youtube.youtube_requests import get_videos as getVideos
import xbmc
import xbmcgui
import os
import urllib
from youtube_requests import get_videos as getVideos
from youtube_requests import get_channels as getChannels
from youtube_requests import v3_request as v3Request
from youtube_requests import __get_core_components as getCoreComponents

class Provider:
  MEDIA_BASE = xbmc.translatePath("special://home")+ "addons" + os.sep + "plugin.video.youtube" + os.sep + "resources" + os.sep + "media" + os.sep 
  count = 0
  def __init__(self, match=None):
    if(match):
      videoId = match.group(1)
      parts = ['snippet,statistics']
      params = {'part': ''.join(parts), 'id': videoId}
      self.videoInfo = v3Request(method='GET', path='videos', params=params)
      self.channelInfo = getChannels(self.videoInfo['items'][0]['snippet']['channelId'])
    return
  def getButtons(self):
    result = []
    result.append(self.getChannelButton())
    result.append(self.getUpVoteButton())
    result.append(self.getDownVoteButton())
    result.append(self.getCommentsButton())
    #result.append(self.getRelatedVideos())
    return result
  def getChannelButton(self):
    channelLogo = self.channelInfo[0]['snippet']['thumbnails']['default']['url']
    channelName = self.channelInfo[0]['snippet']['title']
    return {'label': channelName, 'path': 'action=open&path=plugin://plugin.video.youtube/channel/'+self.channelInfo[0]['id']+'/', 'logo': channelLogo, 'isFolder': True, 'isPlayable': False, 'resolvedUrl':None}
  def getUpVoteButton(self): 
    logo = self.MEDIA_BASE + 'likes.png'
    upVotes = self.videoInfo['items'][0]['statistics']['likeCount']
    return {'label': upVotes, 'path': 'provider=plugin.video.youtube&action=upvote&video_id='+self.videoInfo['items'][0]['id'], 'logo': logo, 'isFolder': True, 'isPlayable':False, 'resolvedUrl':None}
  def getDownVoteButton(self):
    logo = self.MEDIA_BASE + 'dislikes.png'
    downVotes = self.videoInfo['items'][0]['statistics']['dislikeCount']
    return {'label': downVotes, 'path': 'provider=plugin.video.youtube&action=downvote&video_id='+self.videoInfo['items'][0]['id'], 'logo': logo, 'isFolder': True, 'isPlayable':False, 'resolvedUrl':None}
    
  def getCommentsButton(self):
    logo = self.MEDIA_BASE + 'playlist.png'
    return {'label': 'Comments', 'path': 'provider=plugin.video.youtube&action=show_comment&video_id='+self.videoInfo['items'][0]['id'], 'logo': logo, 'isFolder': False, 'isPlayable':False, 'resolvedUrl':None}
  def showComments(self, videoId, page=None):
    print('show comments called xxxxxxxxxxxxxxxxxxxxxx')
    params = {'part': 'snippet',
             'videoId': videoId,
             'order': 'relevance',
             'textFormat': 'plainText',
             'maxResults': '50'}
    if page:
      params['pageToken'] = page
    provider, context, client = getCoreComponents()
    result = client.perform_v3_request(method='GET', path='commentThreads', params=params, no_login=True)
    items = json.loads(result)['items']
    comments = []
    for item in items:
      comment['author'] = item['snippet']['topLevelComment']['authorDisplayName']
      comment['date'] = item['snippet']['topLevelComment']['publishedAt']
      comment['value'] = item['snippet']['topLevelComment']['textOriginal']
      comment['thumb'] = item['snippet']['topLevelComment']['authorProfileImageUrl']
      comment['loadmoreid'] = item['snippet']['id']
      comment['replyId'] = item['snippet']['id']
      comments.append(comment)
    import CommentsDialog
    commentsDialog = CommentsDialog(comments, self.getComments, self.replyToComment)
    commentsDialog.doModal()
  def getComments(self, parent):
    return
  def replyToComment(self, commentId):
    return
  def getTextForCommentsDialog(self, result):
    print(str(result))
    return str(result)
  def doAction(self, action, params):
    print('doAction called 88888888888888888')
    print(str(action))
    print(str(params))
    if('show_comment' == action):
      self.showComments(params['video_id'])
    elif('upvote' == action):
      return
    elif('downvote' == action):
      return
